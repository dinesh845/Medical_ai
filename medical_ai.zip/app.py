from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
import json
from datetime import datetime
import base64
from io import BytesIO
from PIL import Image
import numpy as np
from llm_integration import get_chatbot_response

app = Flask(__name__)
app.config['SECRET_KEY'] = 'medical-ai-secret-key-2026'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
CORS(app)

# Create necessary directories
os.makedirs('uploads/images', exist_ok=True)
os.makedirs('uploads/audio', exist_ok=True)
os.makedirs('data', exist_ok=True)

ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'dcm', 'nii'}
ALLOWED_AUDIO_EXTENSIONS = {'mp3', 'wav', 'ogg', 'm4a'}

def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

def analyze_symptoms(symptoms_data):
    """AI-based symptom analysis"""
    # This is a placeholder for AI model integration
    # You would integrate with TensorFlow, PyTorch, or medical APIs here
    
    symptoms = symptoms_data.get('symptoms', '').lower()
    severity = symptoms_data.get('severity', 'moderate')
    duration = symptoms_data.get('duration', '')
    
    # Sample diagnosis logic (replace with actual AI model)
    possible_conditions = []
    confidence_scores = []
    
    if 'fever' in symptoms or 'temperature' in symptoms:
        possible_conditions.append('Viral Infection')
        confidence_scores.append(0.75)
        if 'cough' in symptoms:
            possible_conditions.append('Respiratory Infection')
            confidence_scores.append(0.68)
    
    if 'headache' in symptoms and 'nausea' in symptoms:
        possible_conditions.append('Migraine')
        confidence_scores.append(0.72)
    
    if 'chest pain' in symptoms or 'breathing' in symptoms:
        possible_conditions.append('Respiratory Issue - Requires Immediate Attention')
        confidence_scores.append(0.80)
    
    if 'stomach' in symptoms or 'abdomen' in symptoms:
        possible_conditions.append('Gastrointestinal Issue')
        confidence_scores.append(0.65)
    
    if not possible_conditions:
        possible_conditions = ['General Consultation Recommended']
        confidence_scores = [0.50]
    
    return {
        'conditions': possible_conditions[:3],
        'confidence': confidence_scores[:3],
        'severity': severity,
        'recommendation': get_recommendation(possible_conditions[0] if possible_conditions else '', severity)
    }

def analyze_medical_image(image_path):
    """AI-based medical image analysis"""
    # Placeholder for medical image analysis (X-ray, CT, MRI)
    # Integrate with specialized medical AI models here
    
    try:
        img = Image.open(image_path)
        img_array = np.array(img)
        
        # Simulate AI analysis
        findings = {
            'image_type': 'Detected',
            'abnormalities': ['No significant abnormalities detected'],
            'confidence': 0.78,
            'requires_specialist': False,
            'notes': 'AI-assisted preliminary screening completed. Professional review recommended.'
        }
        
        return findings
    except Exception as e:
        return {'error': str(e)}

def analyze_audio(audio_path):
    """AI-based audio analysis for voice symptoms"""
    # Placeholder for audio/voice analysis
    # Can include cough detection, breathing patterns, speech analysis
    
    return {
        'audio_processed': True,
        'voice_symptoms': ['Voice pattern analyzed'],
        'confidence': 0.70,
        'notes': 'Audio analysis completed. Additional assessment recommended.'
    }

def get_recommendation(condition, severity):
    """Generate medical recommendations"""
    recommendations = {
        'Viral Infection': 'Rest, stay hydrated, and monitor symptoms. Consult a doctor if fever persists beyond 3 days.',
        'Respiratory Infection': 'Seek medical attention. Rest and avoid strenuous activities.',
        'Migraine': 'Rest in a quiet, dark room. Stay hydrated. Consult a neurologist if frequent.',
        'Respiratory Issue - Requires Immediate Attention': '⚠️ URGENT: Seek immediate medical attention or visit ER.',
        'Gastrointestinal Issue': 'Maintain light diet, stay hydrated. Consult a doctor if symptoms persist.',
        'General Consultation Recommended': 'Schedule an appointment with a healthcare provider for proper evaluation.'
    }
    
    return recommendations.get(condition, 'Consult a healthcare professional for accurate diagnosis.')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/diagnose', methods=['POST'])
def diagnose():
    try:
        data = request.form.to_dict()
        
        # Process text symptoms
        symptoms_analysis = analyze_symptoms(data)
        
        result = {
            'success': True,
            'timestamp': datetime.now().isoformat(),
            'patient_id': f"PAT{datetime.now().strftime('%Y%m%d%H%M%S')}",
            'symptom_analysis': symptoms_analysis,
            'multi_modal_data': {}
        }
        
        # Process uploaded image
        if 'medical_image' in request.files:
            file = request.files['medical_image']
            if file and file.filename and allowed_file(file.filename, ALLOWED_IMAGE_EXTENSIONS):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                filename = timestamp + filename
                filepath = os.path.join('uploads/images', filename)
                file.save(filepath)
                
                image_analysis = analyze_medical_image(filepath)
                result['multi_modal_data']['image_analysis'] = image_analysis
        
        # Process uploaded audio
        if 'audio_file' in request.files:
            file = request.files['audio_file']
            if file and file.filename and allowed_file(file.filename, ALLOWED_AUDIO_EXTENSIONS):
                filename = secure_filename(file.filename)
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                filename = timestamp + filename
                filepath = os.path.join('uploads/audio', filename)
                file.save(filepath)
                
                audio_analysis = analyze_audio(filepath)
                result['multi_modal_data']['audio_analysis'] = audio_analysis
        
        # Save diagnosis record
        save_diagnosis_record(result)
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

@app.route('/api/chat', methods=['POST'])
def chat():
    """AI Health Chatbot endpoint with real LLM integration"""
    try:
        data = request.json
        user_message = data.get('message', '')
        chat_history = data.get('history', [])
        
        # Generate AI response using LLM
        ai_response = get_chatbot_response(user_message, chat_history)
        
        return jsonify({
            'success': True,
            'response': ai_response['message'],
            'suggestions': ai_response.get('suggestions', []),
            'llm_used': ai_response.get('llm_used', 'unknown'),
            'timestamp': datetime.now().isoformat()
        })
    except Exception as e:
        return jsonify({
            'success': False, 
            'error': str(e),
            'fallback_message': 'I apologize, but I encountered an error. For immediate health concerns, please contact your healthcare provider or call 911 for emergencies.'
        }), 500

def save_diagnosis_record(record):
    """Save diagnosis records to JSON file"""
    records_file = 'data/diagnosis_records.json'
    
    try:
        if os.path.exists(records_file):
            with open(records_file, 'r') as f:
                records = json.load(f)
        else:
            records = []
        
        records.append(record)
        
        with open(records_file, 'w') as f:
            json.dump(records, f, indent=2)
    except Exception as e:
        print(f"Error saving record: {e}")

if __name__ == '__main__':
    print("=" * 60)
    print("Medical AI Pre-Diagnosis System Starting...")
    print("=" * 60)
    print("Server running at: http://localhost:5000")
    print("=" * 60)
    app.run(debug=True, host='0.0.0.0', port=5000)
