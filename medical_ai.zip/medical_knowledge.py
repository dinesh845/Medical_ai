"""
Advanced Medical Knowledge Base for AI Chatbot
Provides accurate, evidence-based medical information
"""

class MedicalKnowledgeBase:
    """Comprehensive medical knowledge database"""
    
    def __init__(self):
        self.conditions = self._load_medical_conditions()
        self.symptoms = self._load_symptom_index()
        self.emergency_keywords = [
            'chest pain', 'can\'t breathe', 'difficulty breathing', 'unconscious',
            'severe bleeding', 'suicide', 'overdose', 'seizure', 'stroke',
            'heart attack', 'choking', 'severe burn', 'broken bone'
        ]
    
    def _load_medical_conditions(self):
        """Load medical conditions database"""
        return {
            'fever': {
                'description': 'Elevated body temperature above 100.4°F (38°C)',
                'causes': ['Viral infection', 'Bacterial infection', 'Inflammatory conditions', 'Heat exhaustion'],
                'symptoms': ['Chills', 'Sweating', 'Headache', 'Muscle aches', 'Weakness'],
                'home_care': [
                    'Rest and get plenty of sleep',
                    'Drink fluids (water, clear broths, electrolyte drinks)',
                    'Take acetaminophen (Tylenol) or ibuprofen (Advil) as directed',
                    'Wear lightweight clothing',
                    'Keep room temperature comfortable',
                    'Use cool compresses'
                ],
                'when_to_see_doctor': [
                    'Temperature over 103°F (39.4°C)',
                    'Fever lasts more than 3 days',
                    'Severe headache or stiff neck',
                    'Unusual skin rash',
                    'Difficulty breathing',
                    'Persistent vomiting',
                    'Confusion or difficulty staying awake'
                ],
                'prevention': ['Hand washing', 'Vaccination', 'Avoid sick people', 'Maintain healthy immune system']
            },
            
            'headache': {
                'types': {
                    'tension': 'Dull, aching head pain with tightness across forehead',
                    'migraine': 'Intense throbbing pain, often one-sided, with nausea and light sensitivity',
                    'cluster': 'Severe pain around one eye, occurring in patterns',
                    'sinus': 'Deep, constant pain in cheekbones, forehead, or bridge of nose'
                },
                'triggers': ['Stress', 'Poor posture', 'Lack of sleep', 'Dehydration', 'Certain foods', 'Bright lights', 'Strong odors'],
                'home_care': [
                    'Rest in quiet, dark room',
                    'Apply cold or warm compress to head/neck',
                    'Massage neck and temples',
                    'Stay hydrated',
                    'Take OTC pain relievers (acetaminophen, ibuprofen)',
                    'Practice relaxation (deep breathing, meditation)',
                    'Maintain regular sleep schedule'
                ],
                'red_flags': [
                    'Sudden, severe "thunderclap" headache',
                    'Headache with fever, stiff neck, confusion',
                    'Headache after head injury',
                    'Chronic headache worsening over time',
                    'Headache with vision changes, weakness, or difficulty speaking',
                    'New headache after age 50'
                ]
            },
            
            'cough': {
                'types': {
                    'acute': 'Lasts less than 3 weeks, usually from colds or flu',
                    'subacute': 'Lasts 3-8 weeks, often post-infection',
                    'chronic': 'Lasts more than 8 weeks, may indicate underlying condition'
                },
                'causes': ['Common cold', 'Flu', 'Allergies', 'Asthma', 'GERD', 'Postnasal drip', 'COVID-19'],
                'home_care': [
                    'Stay hydrated (warm liquids especially helpful)',
                    'Use honey (1-2 tsp for adults, not for infants)',
                    'Run humidifier to add moisture to air',
                    'Gargle with warm salt water',
                    'Avoid irritants (smoke, perfumes, cold air)',
                    'Elevate head while sleeping',
                    'Try OTC cough suppressants if needed'
                ],
                'seek_care_if': [
                    'Cough lasting >3 weeks',
                    'Coughing up blood',
                    'Difficulty breathing or wheezing',
                    'Chest pain',
                    'High fever (>103°F)',
                    'Thick, greenish-yellow phlegm',
                    'Cough interfering with sleep or daily activities'
                ]
            },
            
            'stomach_issues': {
                'conditions': {
                    'gastroenteritis': 'Inflammation of stomach and intestines, often viral',
                    'food_poisoning': 'Illness from contaminated food',
                    'indigestion': 'Discomfort after eating',
                    'acid_reflux': 'Stomach acid flowing back into esophagus',
                    'ibs': 'Chronic condition causing cramping and bowel changes'
                },
                'symptoms': ['Nausea', 'Vomiting', 'Diarrhea', 'Cramping', 'Bloating', 'Loss of appetite'],
                'brat_diet': ['Bananas', 'Rice', 'Applesauce', 'Toast'],
                'home_care': [
                    'Stay hydrated with clear fluids (water, broth, electrolyte drinks)',
                    'Start with BRAT diet when able to eat',
                    'Avoid dairy, fatty, spicy, or acidic foods',
                    'Eat small, frequent meals',
                    'Rest and avoid strenuous activity',
                    'Try ginger or peppermint tea for nausea',
                    'Take OTC antacids if heartburn'
                ],
                'urgent_care_needed': [
                    'Severe, persistent abdominal pain',
                    'Blood in vomit or stool',
                    'Signs of dehydration (dry mouth, dark urine, dizziness)',
                    'Unable to keep fluids down for 24 hours',
                    'High fever with abdominal pain',
                    'Vomiting lasting >2 days',
                    'Severe, constant pain in one area'
                ]
            },
            
            'respiratory': {
                'conditions': ['Common cold', 'Flu', 'Bronchitis', 'Pneumonia', 'COVID-19', 'Asthma'],
                'symptoms': ['Cough', 'Shortness of breath', 'Chest tightness', 'Wheezing', 'Congestion'],
                'home_care': [
                    'Get plenty of rest',
                    'Stay well-hydrated',
                    'Use humidifier',
                    'Breathe steam from hot shower',
                    'Take OTC decongestants if needed',
                    'Gargle with salt water',
                    'Avoid smoke and pollutants'
                ],
                'emergency_signs': [
                    'Severe difficulty breathing',
                    'Bluish lips or face',
                    'Chest pain with breathing',
                    'Rapid breathing that won\'t slow',
                    'Can\'t speak in complete sentences',
                    'Confusion or altered consciousness'
                ]
            },
            
            'pain_management': {
                'types': ['Acute (sudden)', 'Chronic (long-term)', 'Nerve pain', 'Inflammatory'],
                'non_medication': [
                    'Rest and ice for injuries (first 48 hours)',
                    'Heat therapy for muscle tension',
                    'Gentle stretching and movement',
                    'Massage therapy',
                    'Physical therapy exercises',
                    'Relaxation techniques',
                    'Good posture',
                    'Adequate sleep'
                ],
                'otc_options': {
                    'acetaminophen': 'Good for pain and fever, gentle on stomach',
                    'ibuprofen': 'Reduces pain, fever, and inflammation',
                    'naproxen': 'Long-lasting pain and inflammation relief',
                    'aspirin': 'Pain, fever, inflammation (not for children)'
                },
                'when_chronic': [
                    'See doctor if pain lasts more than 3 months',
                    'May need comprehensive pain management plan',
                    'Consider physical therapy, psychology, medication',
                    'Rule out underlying conditions'
                ]
            },
            
            'mental_health': {
                'conditions': ['Anxiety', 'Depression', 'Stress', 'Panic attacks', 'PTSD'],
                'symptoms': {
                    'anxiety': ['Excessive worry', 'Restlessness', 'Rapid heartbeat', 'Difficulty concentrating'],
                    'depression': ['Persistent sadness', 'Loss of interest', 'Sleep changes', 'Fatigue', 'Hopelessness']
                },
                'coping_strategies': [
                    'Practice deep breathing (4-7-8 technique)',
                    'Regular physical exercise',
                    'Maintain sleep schedule (7-9 hours)',
                    'Eat balanced diet',
                    'Limit caffeine and alcohol',
                    'Stay connected with others',
                    'Practice mindfulness/meditation',
                    'Journaling',
                    'Set realistic goals',
                    'Take breaks when needed'
                ],
                'professional_help': [
                    'Consult mental health professional if symptoms persist >2 weeks',
                    'Therapy options: CBT, DBT, psychotherapy',
                    'Medication may be beneficial',
                    'Support groups available',
                    'Crisis hotline: 988 (Suicide & Crisis Lifeline)'
                ],
                'emergency': 'If experiencing suicidal thoughts, call 988 or go to nearest ER immediately'
            }
        }
    
    def _load_symptom_index(self):
        """Create searchable symptom index"""
        return {
            'fever': ['fever', 'temperature', 'hot', 'burning up', 'chills'],
            'headache': ['headache', 'head pain', 'migraine', 'head hurt'],
            'cough': ['cough', 'coughing', 'hacking'],
            'stomach': ['stomach', 'nausea', 'vomit', 'diarrhea', 'abdominal', 'belly'],
            'respiratory': ['breathe', 'breathing', 'shortness of breath', 'wheeze', 'congested'],
            'chest_pain': ['chest pain', 'chest hurt', 'chest pressure', 'heart'],
            'anxiety': ['anxiety', 'anxious', 'panic', 'stress', 'worried', 'nervous'],
            'depression': ['depression', 'depressed', 'sad', 'hopeless', 'suicidal'],
            'cold_flu': ['cold', 'flu', 'runny nose', 'sore throat', 'sniffles'],
            'allergy': ['allergy', 'allergic', 'itchy', 'rash', 'hives'],
            'pain': ['pain', 'ache', 'hurt', 'sore'],
            'fatigue': ['tired', 'fatigue', 'exhausted', 'sleepy', 'weak']
        }
    
    def detect_emergency(self, message):
        """Check if message indicates medical emergency"""
        message_lower = message.lower()
        for keyword in self.emergency_keywords:
            if keyword in message_lower:
                return True
        return False
    
    def identify_symptoms(self, message):
        """Identify symptoms mentioned in message"""
        message_lower = message.lower()
        detected = []
        
        for symptom_category, keywords in self.symptoms.items():
            if any(keyword in message_lower for keyword in keywords):
                detected.append(symptom_category)
        
        return detected
    
    def get_response(self, message, symptoms=None):
        """Generate detailed medical response"""
        if self.detect_emergency(message):
            return self._emergency_response()
        
        if symptoms is None:
            symptoms = self.identify_symptoms(message)
        
        if not symptoms:
            return self._general_response(message)
        
        # Generate response for first detected symptom
        primary_symptom = symptoms[0]
        return self._symptom_specific_response(primary_symptom, message)
    
    def _emergency_response(self):
        """Response for medical emergencies"""
        return {
            'message': """🚨 **MEDICAL EMERGENCY DETECTED** 🚨

Based on your message, this may be a medical emergency.

**CALL 911 or local emergency services IMMEDIATELY if you're experiencing:**
- Chest pain or pressure
- Difficulty breathing or shortness of breath
- Sudden severe headache
- Loss of consciousness
- Severe bleeding
- Signs of stroke (face drooping, arm weakness, speech difficulty)
- Thoughts of harming yourself or others

**DO NOT WAIT - SEEK IMMEDIATE MEDICAL ATTENTION**

If this is not an emergency, I'm here to help with other health questions.""",
            'suggestions': ['I called 911', 'Not an emergency', 'Different symptoms']
        }
    
    def _symptom_specific_response(self, symptom, message):
        """Generate detailed response for specific symptom"""
        # This will be filled out based on the symptom
        responses = {
            'fever': self._fever_response,
            'headache': self._headache_response,
            'cough': self._cough_response,
            'stomach': self._stomach_response,
            'respiratory': self._respiratory_response,
            'chest_pain': self._chest_pain_response,
            'anxiety': self._anxiety_response,
            'depression': self._depression_response
        }
        
        response_func = responses.get(symptom, self._general_response)
        return response_func(message)
    
    def _fever_response(self, message):
        info = self.conditions['fever']
        return {
            'message': f"""**Understanding Your Fever**

A fever is your body's natural response to fighting infection. Here's comprehensive guidance:

**What is Fever?**
- Body temperature above 100.4°F (38°C)
- Normal temperature: 97-99°F (36.1-37.2°C)

**Common Causes:**
{self._format_list(info['causes'])}

**Home Care - What You Can Do:**
{self._format_numbered_list(info['home_care'])}

**When to See a Doctor:**
{self._format_list(info['when_to_see_doctor'])}

**Prevention Tips:**
{self._format_list(info['prevention'])}

**Important:** If you're concerned or symptoms worsen, contact your healthcare provider.

Do you have any other symptoms alongside the fever?""",
            'suggestions': ['I have a cough too', 'Severe headache', 'It\'s been 4 days']
        }
    
    def _headache_response(self, message):
        info = self.conditions['headache']
        return {
            'message': f"""**Understanding Your Headache**

Headaches are common but can vary greatly. Let me help you understand and manage them.

**Types of Headaches:**
{self._format_dict(info['types'])}

**Common Triggers:**
{self._format_list(info['triggers'])}

**Relief Strategies:**
{self._format_numbered_list(info['home_care'])}

**⚠️ RED FLAGS - See Doctor Immediately If:**
{self._format_list(info['red_flags'])}

**Tips for Prevention:**
- Maintain regular sleep schedule
- Stay hydrated (8 glasses water daily)
- Manage stress
- Avoid known triggers
- Regular exercise
- Good posture

Would you describe your headache as throbbing, dull, or sharp? This helps determine the type.""",
            'suggestions': ['Throbbing pain', 'Dull ache', 'Sharp/stabbing pain']
        }
    
    def _cough_response(self, message):
        info = self.conditions['cough']
        return {
            'message': f"""**Understanding Your Cough**

Coughing is your body's protective reflex to clear airways. Here's what you need to know:

**Types of Cough:**
{self._format_dict(info['types'])}

**Common Causes:**
{self._format_list(info['causes'])}

**Home Remedies That Work:**
{self._format_numbered_list(info['home_care'])}

**Seek Medical Care If:**
{self._format_list(info['seek_care_if'])}

**Quick Relief Tips:**
- Drink warm liquids (honey lemon tea excellent choice)
- Suck on throat lozenges
- Avoid cold, dry air
- Use cough drops with menthol

Is your cough dry (no mucus) or wet (producing phlegm)? This helps determine best treatment.""",
            'suggestions': ['Dry cough', 'Wet/productive cough', 'Coughing at night']
        }
    
    def _stomach_response(self, message):
        info = self.conditions['stomach_issues']
        return {
            'message': f"""**Understanding Your Stomach Issues**

Digestive problems are common and usually resolve with proper care.

**Common Conditions:**
{self._format_dict(info['conditions'])}

**Symptoms to Watch:**
{self._format_list(info['symptoms'])}

**The BRAT Diet (Easy on stomach):**
{self._format_list(info['brat_diet'])}

**Home Care Steps:**
{self._format_numbered_list(info['home_care'])}

**⚠️ Seek Urgent Care If:**
{self._format_list(info['urgent_care_needed'])}

**Hydration is Key:**
- Sip clear fluids frequently
- Try electrolyte drinks (Pedialyte, Gatorade)
- Avoid caffeine and alcohol
- Start with ice chips if vomiting

How long have you been experiencing these symptoms?""",
            'suggestions': ['Just started today', '2-3 days', 'More than a week']
        }
    
    def _respiratory_response(self, message):
        info = self.conditions['respiratory']
        return {
            'message': f"""**Understanding Respiratory Symptoms**

Breathing problems need careful attention. Here's guidance:

**Common Conditions:**
{self._format_list(info['conditions'])}

**Typical Symptoms:**
{self._format_list(info['symptoms'])}

**Home Care:**
{self._format_numbered_list(info['home_care'])}

**🚨 EMERGENCY SIGNS - Call 911:**
{self._format_list(info['emergency_signs'])}

**Breathing Exercises:**
1. Diaphragmatic breathing (belly breathing)
2. Pursed-lip breathing
3. Practice when calm to use during difficulty

**Important:** Any significant breathing difficulty should be evaluated by a healthcare provider.

Are you currently having difficulty breathing?""",
            'suggestions': ['Yes, hard to breathe', 'Mild difficulty', 'Just congested']
        }
    
    def _chest_pain_response(self, message):
        return {
            'message': """🚨 **CHEST PAIN REQUIRES IMMEDIATE ATTENTION** 🚨

**CALL 911 IMMEDIATELY if experiencing:**
- Crushing, squeezing, or pressure in chest
- Pain spreading to arm, jaw, neck, or back
- Shortness of breath
- Sweating, nausea, lightheadedness
- Feeling of impending doom

**HEART ATTACK SYMPTOMS:**
- Chest discomfort (center/left side)
- Pain lasting more than few minutes
- May come and go
- Women may have atypical symptoms (fatigue, nausea, back/jaw pain)

**Other Serious Causes:**
- Pulmonary embolism
- Aortic dissection
- Pneumothorax (collapsed lung)

**Less Urgent (but still see doctor):**
- Muscle strain
- Costochondritis (rib inflammation)
- Acid reflux/GERD
- Anxiety/panic attack

**IMPORTANT:** NEVER ignore chest pain. When in doubt, seek immediate medical evaluation.

Are you currently experiencing chest pain? If yes, call 911 now.""",
            'suggestions': ['Calling 911 now', 'It\'s mild discomfort', 'Previous chest pain']
        }
    
    def _anxiety_response(self, message):
        info = self.conditions['mental_health']
        return {
            'message': f"""**Understanding Anxiety**

Mental health is as important as physical health. You're not alone, and help is available.

**Common Anxiety Symptoms:**
{self._format_list(info['symptoms']['anxiety'])}

**Effective Coping Strategies:**
{self._format_numbered_list(info['coping_strategies'])}

**4-7-8 Breathing Technique:**
1. Exhale completely through mouth
2. Inhale through nose for 4 counts
3. Hold breath for 7 counts
4. Exhale through mouth for 8 counts
5. Repeat 3-4 times

**5-4-3-2-1 Grounding:**
- Name 5 things you see
- 4 things you can touch
- 3 things you hear
- 2 things you smell
- 1 thing you taste

**When to Seek Professional Help:**
{self._format_list(info['professional_help'])}

**Crisis Support:**
- Mental Health Crisis: Call/Text 988
- Crisis Text Line: Text HOME to 741741

Remember: Anxiety is treatable. With proper support, you can feel better.

Would you like specific techniques or resources?""",
            'suggestions': ['Breathing techniques', 'Find a therapist', 'Crisis support']
        }
    
    def _depression_response(self, message):
        info = self.conditions['mental_health']
        return {
            'message': f"""**Understanding Depression**

Depression is a medical condition, not a weakness. Support and treatment are available.

**Common Symptoms:**
{self._format_list(info['symptoms']['depression'])}

**Self-Care Steps:**
{self._format_numbered_list(info['coping_strategies'][:8])}

**Professional Treatment:**
{self._format_list(info['professional_help'])}

**Immediate Help Available:**
- **988 Suicide & Crisis Lifeline**: Call or text 988
- **Crisis Text Line**: Text HOME to 741741
- **Emergency**: Call 911 or go to nearest ER

**Remember:**
- Depression is treatable
- You're not alone - millions experience this
- Asking for help is a sign of strength
- Recovery is possible with proper support

**⚠️ If you're having thoughts of suicide, please reach out immediately.**

Are you currently safe? Would you like crisis resources?""",
            'suggestions': ['I need crisis help', 'Finding a therapist', 'Self-care tips']
        }
    
    def _general_response(self, message):
        return {
            'message': """**Hello! I'm Here to Help**

I'm your AI Medical Assistant, ready to provide health information and guidance.

**I can help with:**
- Understanding symptoms and conditions
- Home care recommendations
- When to seek medical care
- General health information
- Wellness and prevention tips

**How to get the best help:**
Please describe your specific symptoms or health concern. For example:
- "I have a fever and sore throat"
- "I'm experiencing headaches every day"
- "I feel anxious and can't sleep"

**Important Reminders:**
- This is general information, not medical diagnosis
- Always consult healthcare professionals for medical decisions
- Call 911 for emergencies
- Your health and safety are the priority

**What specific symptoms or health concern can I help you understand today?**""",
            'suggestions': ['I have symptoms', 'General health question', 'Emergency information']
        }
    
    def _format_list(self, items):
        """Format list with bullet points"""
        return '\n'.join([f"• {item}" for item in items])
    
    def _format_numbered_list(self, items):
        """Format numbered list"""
        return '\n'.join([f"{i+1}. {item}" for i, item in enumerate(items)])
    
    def _format_dict(self, dict_items):
        """Format dictionary as list"""
        return '\n'.join([f"• **{key.title()}**: {value}" for key, value in dict_items.items()])


# Global knowledge base instance
medical_kb = MedicalKnowledgeBase()
