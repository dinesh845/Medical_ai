// ===========================
// Global Variables
// ===========================
let diagnosisData = null;
let imageFile = null;
let audioFile = null;

// ===========================
// Event Listeners
// ===========================
document.addEventListener('DOMContentLoaded', function() {
    initializeEventListeners();
    initializeFileUploads();
    initializeScrollAnimations();
});

function initializeEventListeners() {
    // Form submission
    const diagnosisForm = document.getElementById('diagnosisForm');
    if (diagnosisForm) {
        diagnosisForm.addEventListener('submit', handleFormSubmit);
    }

    // Mobile menu toggle
    const mobileMenuToggle = document.getElementById('mobileMenuToggle');
    if (mobileMenuToggle) {
        mobileMenuToggle.addEventListener('click', toggleMobileMenu);
    }

    // Navigation links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', handleNavClick);
    });

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
}

function initializeFileUploads() {
    // Image upload
    const imageInput = document.getElementById('medicalImage');
    if (imageInput) {
        imageInput.addEventListener('change', function(e) {
            handleImageUpload(e.target.files[0]);
        });
    }

    // Audio upload
    const audioInput = document.getElementById('audioFile');
    if (audioInput) {
        audioInput.addEventListener('change', function(e) {
            handleAudioUpload(e.target.files[0]);
        });
    }
}

// ===========================
// Navigation Functions
// ===========================
function toggleMobileMenu() {
    const navMenu = document.querySelector('.nav-menu');
    navMenu.classList.toggle('active');
}

function handleNavClick(e) {
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => link.classList.remove('active'));
    e.target.classList.add('active');
}

function scrollToDiagnosis() {
    const diagnosisSection = document.getElementById('diagnosis');
    if (diagnosisSection) {
        diagnosisSection.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }
}

// ===========================
// File Upload Handling
// ===========================
function handleImageUpload(file) {
    if (!file) return;

    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
    const maxSize = 16 * 1024 * 1024; // 16MB

    if (!allowedTypes.includes(file.type)) {
        showNotification('Please upload a valid image file (JPG, PNG)', 'error');
        return;
    }

    if (file.size > maxSize) {
        showNotification('Image size should be less than 16MB', 'error');
        return;
    }

    imageFile = file;

    // Show preview
    const reader = new FileReader();
    reader.onload = function(e) {
        const preview = document.getElementById('imagePreview');
        const previewImg = document.getElementById('imagePreviewImg');
        const fileName = document.getElementById('imageFileName');
        const uploadContent = document.querySelector('#imageUploadBox .upload-content');

        previewImg.src = e.target.result;
        fileName.textContent = file.name;
        preview.style.display = 'block';
        uploadContent.style.display = 'none';
    };
    reader.readAsDataURL(file);

    showNotification('Medical image uploaded successfully', 'success');
}

function handleAudioUpload(file) {
    if (!file) return;

    const allowedTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/ogg', 'audio/m4a'];
    const maxSize = 16 * 1024 * 1024; // 16MB

    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(mp3|wav|ogg|m4a)$/i)) {
        showNotification('Please upload a valid audio file (MP3, WAV, OGG, M4A)', 'error');
        return;
    }

    if (file.size > maxSize) {
        showNotification('Audio size should be less than 16MB', 'error');
        return;
    }

    audioFile = file;

    // Show preview
    const preview = document.getElementById('audioPreview');
    const fileName = document.getElementById('audioFileName');
    const uploadContent = document.querySelector('#audioUploadBox .upload-content');

    fileName.textContent = file.name;
    preview.style.display = 'block';
    uploadContent.style.display = 'none';

    showNotification('Audio file uploaded successfully', 'success');
}

function removeFile(type) {
    if (type === 'image') {
        imageFile = null;
        document.getElementById('medicalImage').value = '';
        document.getElementById('imagePreview').style.display = 'none';
        document.querySelector('#imageUploadBox .upload-content').style.display = 'flex';
    } else if (type === 'audio') {
        audioFile = null;
        document.getElementById('audioFile').value = '';
        document.getElementById('audioPreview').style.display = 'none';
        document.querySelector('#audioUploadBox .upload-content').style.display = 'flex';
    }
    showNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} removed`, 'info');
}

// ===========================
// Form Submission
// ===========================
async function handleFormSubmit(e) {
    e.preventDefault();

    // Validate form
    if (!validateForm()) {
        return;
    }

    // Prepare form data
    const formData = new FormData();
    formData.append('patientName', document.getElementById('patientName').value);
    formData.append('age', document.getElementById('age').value);
    formData.append('gender', document.getElementById('gender').value);
    formData.append('contact', document.getElementById('contact').value);
    formData.append('symptoms', document.getElementById('symptoms').value);
    formData.append('duration', document.getElementById('duration').value);
    formData.append('severity', document.getElementById('severity').value);

    if (imageFile) {
        formData.append('medical_image', imageFile);
    }

    if (audioFile) {
        formData.append('audio_file', audioFile);
    }

    // Show loading
    showLoading();

    try {
        const response = await fetch('/api/diagnose', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error('Diagnosis failed. Please try again.');
        }

        const result = await response.json();
        
        if (result.success) {
            diagnosisData = result;
            hideLoading();
            displayResults(result);
            showNotification('Diagnosis completed successfully', 'success');
        } else {
            throw new Error(result.error || 'Diagnosis failed');
        }
    } catch (error) {
        hideLoading();
        showNotification(error.message, 'error');
        console.error('Error:', error);
    }
}

function validateForm() {
    const requiredFields = [
        { id: 'patientName', name: 'Name' },
        { id: 'age', name: 'Age' },
        { id: 'gender', name: 'Gender' },
        { id: 'symptoms', name: 'Symptoms' },
        { id: 'duration', name: 'Duration' },
        { id: 'severity', name: 'Severity' }
    ];

    for (const field of requiredFields) {
        const element = document.getElementById(field.id);
        if (!element.value.trim()) {
            showNotification(`Please fill in ${field.name}`, 'error');
            element.focus();
            return false;
        }
    }

    return true;
}

// ===========================
// Loading Functions
// ===========================
function showLoading() {
    document.getElementById('diagnosisForm').style.display = 'none';
    document.getElementById('loadingContainer').style.display = 'block';
    document.getElementById('resultsContainer').style.display = 'none';

    // Animate loading steps
    setTimeout(() => {
        document.getElementById('step1').innerHTML = '<i class="fas fa-check-circle"></i> Analyzing symptoms';
    }, 1000);

    setTimeout(() => {
        document.getElementById('step2').innerHTML = '<i class="fas fa-check-circle"></i> Processing medical data';
        document.getElementById('step3').innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating diagnosis';
    }, 2000);

    setTimeout(() => {
        document.getElementById('step3').innerHTML = '<i class="fas fa-check-circle"></i> Generating diagnosis';
    }, 3000);
}

function hideLoading() {
    document.getElementById('loadingContainer').style.display = 'none';
}

// ===========================
// Results Display
// ===========================
function displayResults(data) {
    // Display patient info
    displayPatientInfo(data);

    // Display diagnosis
    displayDiagnosis(data.symptom_analysis);

    // Display recommendations
    displayRecommendations(data.symptom_analysis);

    // Display multi-modal results
    displayMultiModalResults(data.multi_modal_data);

    // Show results container
    document.getElementById('resultsContainer').style.display = 'block';

    // Scroll to results
    setTimeout(() => {
        document.getElementById('resultsContainer').scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    }, 300);
}

function displayPatientInfo(data) {
    const patientInfoDiv = document.getElementById('patientInfoResult');
    const patientName = document.getElementById('patientName').value;
    const age = document.getElementById('age').value;
    const gender = document.getElementById('gender').value;

    patientInfoDiv.innerHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
            <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 3px solid var(--secondary-color);">
                <strong>Patient ID:</strong><br>
                <span style="color: var(--text-secondary);">${data.patient_id}</span>
            </div>
            <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 3px solid var(--secondary-color);">
                <strong>Name:</strong><br>
                <span style="color: var(--text-secondary);">${patientName}</span>
            </div>
            <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 3px solid var(--secondary-color);">
                <strong>Age:</strong><br>
                <span style="color: var(--text-secondary);">${age} years</span>
            </div>
            <div style="padding: 1rem; background: white; border-radius: 8px; border-left: 3px solid var(--secondary-color);">
                <strong>Gender:</strong><br>
                <span style="color: var(--text-secondary);">${gender.charAt(0).toUpperCase() + gender.slice(1)}</span>
            </div>
        </div>
    `;
}

function displayDiagnosis(analysis) {
    const diagnosisDiv = document.getElementById('diagnosisResult');
    let html = '';

    if (analysis.conditions && analysis.conditions.length > 0) {
        analysis.conditions.forEach((condition, index) => {
            const confidence = analysis.confidence[index];
            const confidencePercent = Math.round(confidence * 100);
            const confidenceColor = confidence > 0.7 ? 'var(--success-color)' : confidence > 0.5 ? 'var(--warning-color)' : 'var(--danger-color)';

            html += `
                <div class="condition-item">
                    <div>
                        <div class="condition-name">${condition}</div>
                        <small style="color: var(--text-secondary);">AI Confidence Level</small>
                    </div>
                    <div class="confidence-badge" style="background: ${confidenceColor};">
                        ${confidencePercent}%
                    </div>
                </div>
            `;
        });

        html += `
            <div style="margin-top: 1.5rem; padding: 1rem; background: rgba(79, 70, 229, 0.1); border-radius: 8px;">
                <strong style="color: var(--primary-color);">Severity Level:</strong>
                <span style="margin-left: 0.5rem; text-transform: capitalize; font-weight: 600;">
                    ${analysis.severity}
                </span>
            </div>
        `;
    } else {
        html = '<p style="color: var(--text-secondary);">No specific conditions detected. General consultation recommended.</p>';
    }

    diagnosisDiv.innerHTML = html;
}

function displayRecommendations(analysis) {
    const recommendationDiv = document.getElementById('recommendationResult');
    
    let html = `
        <div style="padding: 1.5rem; background: white; border-radius: 8px; border-left: 4px solid var(--success-color);">
            <p style="font-size: 1.05rem; line-height: 1.8; color: var(--text-primary); margin-bottom: 1rem;">
                ${analysis.recommendation}
            </p>
            <div style="background: #FEF3C7; padding: 1rem; border-radius: 8px; border-left: 3px solid var(--warning-color);">
                <strong style="color: #92400E;"><i class="fas fa-exclamation-triangle"></i> Important:</strong>
                <p style="color: #92400E; margin: 0.5rem 0 0 0;">
                    This is a preliminary AI-based assessment. Please consult with a qualified healthcare professional for accurate diagnosis and treatment.
                </p>
            </div>
        </div>
    `;

    recommendationDiv.innerHTML = html;
}

function displayMultiModalResults(multiModalData) {
    const multiModalDiv = document.getElementById('multiModalResults');
    let html = '';

    // Image analysis results
    if (multiModalData.image_analysis) {
        const imgAnalysis = multiModalData.image_analysis;
        html += `
            <div class="result-card" style="border-left: 4px solid #F59E0B;">
                <h4><i class="fas fa-x-ray"></i> Medical Image Analysis</h4>
                <div style="padding: 1rem; background: white; border-radius: 8px;">
                    <p><strong>Image Type:</strong> ${imgAnalysis.image_type}</p>
                    <p><strong>Confidence:</strong> ${Math.round(imgAnalysis.confidence * 100)}%</p>
                    <div style="margin-top: 1rem;">
                        <strong>Findings:</strong>
                        <ul style="margin-top: 0.5rem; padding-left: 1.5rem;">
                            ${imgAnalysis.abnormalities.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>
                    <p style="margin-top: 1rem; color: var(--text-secondary); font-style: italic;">
                        ${imgAnalysis.notes}
                    </p>
                </div>
            </div>
        `;
    }

    // Audio analysis results
    if (multiModalData.audio_analysis) {
        const audioAnalysis = multiModalData.audio_analysis;
        html += `
            <div class="result-card" style="border-left: 4px solid #06B6D4;">
                <h4><i class="fas fa-microphone"></i> Audio Analysis</h4>
                <div style="padding: 1rem; background: white; border-radius: 8px;">
                    <p><strong>Status:</strong> ${audioAnalysis.audio_processed ? 'Processed Successfully' : 'Processing Failed'}</p>
                    <p><strong>Confidence:</strong> ${Math.round(audioAnalysis.confidence * 100)}%</p>
                    <div style="margin-top: 1rem;">
                        <strong>Findings:</strong>
                        <ul style="margin-top: 0.5rem; padding-left: 1.5rem;">
                            ${audioAnalysis.voice_symptoms.map(item => `<li>${item}</li>`).join('')}
                        </ul>
                    </div>
                    <p style="margin-top: 1rem; color: var(--text-secondary); font-style: italic;">
                        ${audioAnalysis.notes}
                    </p>
                </div>
            </div>
        `;
    }

    multiModalDiv.innerHTML = html;
}

// ===========================
// Form Reset
// ===========================
function resetForm() {
    // Reset form
    document.getElementById('diagnosisForm').reset();
    
    // Clear files
    imageFile = null;
    audioFile = null;
    
    // Reset file previews
    document.getElementById('imagePreview').style.display = 'none';
    document.getElementById('audioPreview').style.display = 'none';
    document.querySelector('#imageUploadBox .upload-content').style.display = 'flex';
    document.querySelector('#audioUploadBox .upload-content').style.display = 'flex';
    
    // Show form, hide results
    document.getElementById('diagnosisForm').style.display = 'block';
    document.getElementById('resultsContainer').style.display = 'none';
    
    // Scroll to form
    document.getElementById('diagnosis').scrollIntoView({
        behavior: 'smooth',
        block: 'start'
    });
    
    showNotification('Form reset. Ready for new diagnosis.', 'info');
}

// ===========================
// Report Functions
// ===========================
function downloadReport() {
    if (!diagnosisData) {
        showNotification('No diagnosis data available', 'error');
        return;
    }

    const reportContent = generateReportContent();
    const blob = new Blob([reportContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Medical_Report_${diagnosisData.patient_id}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    showNotification('Report downloaded successfully', 'success');
}

function generateReportContent() {
    const patientName = document.getElementById('patientName').value;
    const age = document.getElementById('age').value;
    const gender = document.getElementById('gender').value;
    
    return `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <title>Medical Report - ${diagnosisData.patient_id}</title>
            <style>
                body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
                h1 { color: #4F46E5; border-bottom: 3px solid #4F46E5; padding-bottom: 10px; }
                .section { margin: 20px 0; padding: 20px; border: 1px solid #E5E7EB; border-radius: 8px; }
                .label { font-weight: bold; color: #374151; }
                .value { color: #6B7280; }
                .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #E5E7EB; font-size: 12px; color: #9CA3AF; }
            </style>
        </head>
        <body>
            <h1>🏥 MediAI - Medical Pre-Diagnosis Report</h1>
            
            <div class="section">
                <h2>Patient Information</h2>
                <p><span class="label">Patient ID:</span> <span class="value">${diagnosisData.patient_id}</span></p>
                <p><span class="label">Name:</span> <span class="value">${patientName}</span></p>
                <p><span class="label">Age:</span> <span class="value">${age} years</span></p>
                <p><span class="label">Gender:</span> <span class="value">${gender}</span></p>
                <p><span class="label">Date:</span> <span class="value">${new Date(diagnosisData.timestamp).toLocaleString()}</span></p>
            </div>
            
            <div class="section">
                <h2>Diagnosis Results</h2>
                ${diagnosisData.symptom_analysis.conditions.map((condition, index) => `
                    <p><span class="label">• ${condition}</span> - Confidence: ${Math.round(diagnosisData.symptom_analysis.confidence[index] * 100)}%</p>
                `).join('')}
            </div>
            
            <div class="section">
                <h2>Recommendations</h2>
                <p>${diagnosisData.symptom_analysis.recommendation}</p>
            </div>
            
            <div class="footer">
                <p><strong>Disclaimer:</strong> This is an AI-generated preliminary assessment. Always consult with a qualified healthcare professional for accurate diagnosis and treatment.</p>
                <p>Generated by MediAI - Advanced Medical Pre-Diagnosis System</p>
            </div>
        </body>
        </html>
    `;
}

function shareReport() {
    if (!diagnosisData) {
        showNotification('No diagnosis data available', 'error');
        return;
    }

    const shareText = `Medical Pre-Diagnosis Report\nPatient ID: ${diagnosisData.patient_id}\nDate: ${new Date(diagnosisData.timestamp).toLocaleString()}`;

    if (navigator.share) {
        navigator.share({
            title: 'Medical Report',
            text: shareText,
            url: window.location.href
        }).then(() => {
            showNotification('Report shared successfully', 'success');
        }).catch(() => {
            copyToClipboard(shareText);
        });
    } else {
        copyToClipboard(shareText);
    }
}

function copyToClipboard(text) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    showNotification('Report details copied to clipboard', 'info');
}

// ===========================
// Notification System
// ===========================
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    
    const icons = {
        success: 'fa-check-circle',
        error: 'fa-exclamation-circle',
        warning: 'fa-exclamation-triangle',
        info: 'fa-info-circle'
    };

    const colors = {
        success: '#10B981',
        error: '#EF4444',
        warning: '#F59E0B',
        info: '#3B82F6'
    };

    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: white;
        color: var(--text-primary);
        padding: 1rem 1.5rem;
        border-radius: 12px;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
        display: flex;
        align-items: center;
        gap: 0.75rem;
        z-index: 10000;
        animation: slideInRight 0.3s ease-out;
        border-left: 4px solid ${colors[type]};
        max-width: 400px;
    `;

    notification.innerHTML = `
        <i class="fas ${icons[type]}" style="color: ${colors[type]}; font-size: 1.25rem;"></i>
        <span style="flex: 1;">${message}</span>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: var(--text-secondary); cursor: pointer; font-size: 1.25rem;">
            <i class="fas fa-times"></i>
        </button>
    `;

    document.body.appendChild(notification);

    setTimeout(() => {
        notification.style.animation = 'slideOutRight 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 5000);
}

// ===========================
// Scroll Animations
// ===========================
function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.animation = 'fadeInUp 0.6s ease-out';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements
    document.querySelectorAll('.feature-card, .result-card').forEach(el => {
        observer.observe(el);
    });
}

// Add CSS for notification animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }

    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
